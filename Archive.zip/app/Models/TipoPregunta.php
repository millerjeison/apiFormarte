<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TipoPregunta extends Model
{
    protected $fillable = [
        'value'
    ];

    // Define las relaciones aquí si es necesario
}